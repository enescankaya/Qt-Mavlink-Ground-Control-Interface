#ifndef HUD_H
#define HUD_H

#include <QWidget>
#include <QTimer>
#include <QtConcurrent>
namespace Ui {
class HUD;
}

class HUD : public QWidget
{
    Q_OBJECT
public slots:
    void setPitch(double value);
    void setAirSpeed(double value);
    void setRoll(double value);
    void setYaw(double value);
    void redraw();
    void setAltitude(double value);
    void setPressure(double value);
    void setVerticleSpeed(double value);
    void setCourse(double value);
    void setNavigation(double bearing,double deviation,double distance);
    void reset();

public:
    explicit HUD(QWidget *parent = nullptr);
    ~HUD();

private:
    Ui::HUD *ui;

};

#endif // HUD_H
