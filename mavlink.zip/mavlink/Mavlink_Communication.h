#ifndef MAVLINK_COMMUNICATION_H
#define MAVLINK_COMMUNICATION_H
#include <QObject>
#include <QThread>
#include <QDebug>
#include "mavlink.h"
#include <mavlink_helpers.h>
#include <mavlink_conversions.h>
#include <mavlink_message_names.h>
#include <QTcpSocket>
#include <ui_mainwindow.h>
//#include <QDateTime>
#include <QtConcurrent>
class Show_Values_Class: public QThread
{
    Q_OBJECT

public:
    explicit Show_Values_Class(QObject *parent = nullptr);
    QTcpSocket *tcpSocket;
    uint32_t startTime = 0;

public slots:
    void Go_Coordinate(double lat, double lng);
    void Remove_Coordinate();
    void Arm();
    void disArm();
    void Connect_TCP(QString ip, quint16 port);
    void DisConnect_TCP();
    void change_Mode(int indexofCombobox);
    void Heartbeat();
    void run();
    void readData();
private:
    void processMAVLinkMessage(const mavlink_message_t& msg);
    void handleGlobalPosition(const mavlink_message_t& msg);
    void handleAttitude(const mavlink_message_t& msg);
    void handleAirspeed(const mavlink_message_t& msg);
    void handlePressure(const mavlink_message_t& msg);
    void handleNavigation(const mavlink_message_t& msg);
    void sendMavlinkMessage(const mavlink_message_t& msg);
    bool TCPconnected;
    QString message;
    QString messageInfo;
    QString messageId;
    QString messageName;
    mavlink_message_t msg;
    mavlink_status_t status = {};
    uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
    QThread *readDataThread;
signals:
    void messageChanged();
    void TCPError();
    void updateLabelBackground(bool state,uint32_t  time);//green=true,red=false
    void addMessageInfoToLabel(QString message);
    void addMessageToLabel(QString message);
    void updateConnectionStatus(bool TCPconnected);
    void messageBox_Show(QString title,QString message);
    void setAirSpeed(double value);
    void setRoll(double value);
    void setPitch(double value);
    void setYaw(double value);
    void setAltitude(double value);
    void setPressure(double value);
    void setVerticleSpeed(double value);
    void setCourse(double value);
    void setNavigation(double bearing,double deviation,double distance);
    void setMap(QVariant, QVariant,QVariant);
    void connecting_tcp();
};
#endif // MAVLINK_COMMUNICATION_H
