#include "hud.h"
#include "ui_hud.h"


HUD::HUD(QWidget *parent):
    QWidget(parent),
    ui(new Ui::HUD)
{
    ui->setupUi(this);
}
HUD::~HUD()
{
    delete ui;
}
void HUD::setPitch(double value){
        ui->graphicsView->setPitch(int(value));
        ui->graphicsView_6->setPitch(value);
        ui->graphicsView_7->setTurnRate(value);

        // Grafik güncellemeleri
        ui->graphicsView_6->redraw();
        ui->graphicsView->redraw();
        ui->graphicsView_7->redraw();

}
void HUD::setRoll(double value){
    ui->graphicsView->setRoll(int(value));
    ui->graphicsView_6->setRoll(value);
    ui->graphicsView_7->setSlipSkid(value);
    ui->graphicsView->redraw();
    ui->graphicsView_6->redraw();
    ui->graphicsView_7->redraw();

}
void HUD::setAirSpeed(double value){
    ui->graphicsView->setAirspeed(int(value));
    ui->graphicsView_3->setAirspeed(int(value));
    ui->graphicsView->redraw();
    ui->graphicsView_3->redraw();


}
void HUD::setYaw(double value){
    ui->graphicsView->setHeading(int(value));
    ui->graphicsView_5->setHeading(int(value));
    ui->graphicsView_8->setHeading(int(value));
    ui->graphicsView_5->redraw();
    ui->graphicsView->redraw();
    ui->graphicsView_8->redraw();


}
void HUD::setAltitude(double value){
    ui->graphicsView->setAltitude(abs(value));
    ui->graphicsView_2->setAltitude(abs(value));
    ui->graphicsView->redraw();
    ui->graphicsView->redraw();
    ui->graphicsView_2->redraw();

}
void HUD::setPressure(double value){
    ui->graphicsView_2->setPressure(value/ 33.8639);//inHg dönüşümü
    ui->graphicsView_2->redraw();

}
void HUD::setVerticleSpeed(double value){
    ui->graphicsView->setClimbRate(value);
    ui->graphicsView_4->setClimbRate(value*196.85);
    ui->graphicsView->redraw();
    ui->graphicsView_4->redraw();
}
void HUD::setCourse(double value){
    ui->graphicsView_5->setCourse(value);
    ui->graphicsView_5->redraw();
}
void HUD::setNavigation(double bearing,double deviation,double distance){
    ui->graphicsView_5->setBearing(bearing);
    ui->graphicsView_5->setDeviation(deviation);
    ui->graphicsView_5->setDistance(distance);
    ui->graphicsView_5->redraw();
}
void HUD::reset(){
    ui->graphicsView->reinit();
    ui->graphicsView_2->reinit();
    ui->graphicsView_3->reinit();
    ui->graphicsView_4->reinit();
    ui->graphicsView_5->reinit();
    ui->graphicsView_6->reinit();
    ui->graphicsView_7->reinit();
    ui->graphicsView_8->reinit();
}
