#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "hud.h"
#include "ui_mainwindow.h"
#include <QMainWindow>
#include <QListWidget>
#include "Mavlink_Communication.h"
#include "hud.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void showTCPError();
    void messageBox_Show(QString title,QString message);
    HUD *hud;

private:
    Ui::MainWindow *ui;
    bool ScrollBar=true;
    bool ScrollBar_2=true;
    bool armed=false;
    int combo_Selected_Index= 0;
    uint8_t main_mode;
    Show_Values_Class *show_values_class;
    QTcpSocket *tcpSocket;
    void setupConnections();
    QTimer *timer;
    QString text = "Connecting";
    int dotCount = 0; // Nokta sayacı

private slots:
    void on_connectButton_clicked();
    void on_disconnectButton_clicked();
    void on_ArmButton_clicked();
    void updateConnectionStatus(bool TCPconnected);
    void updateButtonStyles();
    void on_DisarmButton_clicked();
    void onDisconnected();
    void on_ChangeModeButton_clicked();
    void on_ModeListCombobox_currentIndexChanged(int index);
    void updateLabelBackground(bool isProgressing,uint32_t time);
    void addMessageInfoToLabel(QString message);
    void addMessageToLabel(QString message);
    void connecting_tcp();
signals:
    void Arm();
    void DisArm();
    void Connect(QString ip,quint16 port);
    void DisConnect();
    void changeMode(int indexofCombobox);
};

#endif // MAINWINDOW_H
