#include "Mavlink_Communication.h"
#include <QMessageBox>
Show_Values_Class::Show_Values_Class(QObject *parent):
    QThread(parent),
    tcpSocket(new QTcpSocket(this))
{
    connect(tcpSocket, &QTcpSocket::readyRead, this, &Show_Values_Class::readData);
    connect(tcpSocket, &QTcpSocket::connected, this, [this]() {
        emit updateConnectionStatus(true);
        emit messageBox_Show("Connection", "Connected successfully.");
    });

    connect(tcpSocket, &QTcpSocket::errorOccurred, this, [this](QAbstractSocket::SocketError socketError) {
        Q_UNUSED(socketError);
        emit updateConnectionStatus(false);
        emit messageBox_Show("Connection Failed", "Could not connect to server.");
        emit updateConnectionStatus(TCPconnected = false);
        tcpSocket->abort();  // Hata durumunda bağlantıyı sıfırla
    });
}
void Show_Values_Class::readData() {
    this->start();
}
void Show_Values_Class::run(){
    while (tcpSocket->bytesAvailable() > 0) {
        int bytesRead = tcpSocket->read(reinterpret_cast<char*>(buffer), MAVLINK_MAX_PACKET_LEN);
        if (bytesRead <= 0) {
            emit TCPError(); // Veri okunamadığında hata sinyali gönder
            return;
        }
        for (int i = 0; i < bytesRead; i++) {
            if (mavlink_parse_char(MAVLINK_COMM_0, buffer[i], &msg, &status)) {//bir kere okudugunu bir daha okumuyoriö
                processMAVLinkMessage(msg);
            }
        }
        Heartbeat();
        QThread::msleep(30);
    }
}
void Show_Values_Class::processMAVLinkMessage(const mavlink_message_t& msg) {
    // Mesaj adını ve kimliğini al
    messageName = QString::fromUtf8(getMessageName(msg.msgid));
    messageId = QString::number(msg.msgid);
    messageInfo.append(QString("%1 - %2\n").arg(messageName, messageId));
    switch (msg.msgid) {
    case MAVLINK_MSG_ID_GLOBAL_POSITION_INT:
        handleGlobalPosition(msg);
        break;
    case MAVLINK_MSG_ID_ATTITUDE:
        handleAttitude(msg);
        break;
    case MAVLINK_MSG_ID_VFR_HUD:
        handleAirspeed(msg);
        break;
    case MAVLINK_MSG_ID_SCALED_PRESSURE:
        handlePressure(msg);
        break;
    case MAVLINK_MSG_ID_NAV_CONTROLLER_OUTPUT:
        handleNavigation(msg);
        break;
    default:
        break;
    }
}
void Show_Values_Class::handleNavigation(const mavlink_message_t& msg) {
    mavlink_nav_controller_output_t nav_output;
    mavlink_msg_nav_controller_output_decode(&msg, &nav_output);
    emit setNavigation(nav_output.target_bearing,nav_output.nav_bearing,nav_output.wp_dist / 1852.0);
}
void Show_Values_Class::handleAirspeed(const mavlink_message_t& msg) {
    mavlink_vfr_hud_t vfrHud;
    mavlink_msg_vfr_hud_decode(&msg, &vfrHud);
    emit setAirSpeed(vfrHud.airspeed);
    emit setCourse(vfrHud.heading);
}

void Show_Values_Class::handleGlobalPosition(const mavlink_message_t& msg) {
    mavlink_global_position_int_t global_position;
    mavlink_msg_global_position_int_decode(&msg, &global_position);
    double R_altitude = global_position.relative_alt / 1000.0;
    double vertical_speed = global_position.vz / 100.0f;
    double altitude=global_position.alt / 1000.0;
    message.append(QString("RELATIVE ALTITUDE: %1 M\n\n").arg(R_altitude));
    message.append(QString("DİK HIZ: %1 M/S\n\n").arg(vertical_speed));
    message.append(QString("ALTITUDE: %1 M\n\n").arg(altitude));
    message.append(QString("(VX) HIZ: %1 M/S\n\n").arg(global_position.vx / 100.0));
    message.append(QString("(VY) HIZ: %1 M/S\n\n").arg(global_position.vy / 100.0));
    message.append(QString("(VZ) HIZ: %1 M/S\n\n").arg(global_position.vz / 100.0));
    message.append(QString("LATITUDE: %1\n\n").arg(global_position.lat / 1e7));
    message.append(QString("LONGITUDE: %1\n\n").arg(global_position.lon / 1e7));
    message.append(QString("YAW: %1 DEG\n\n").arg(global_position.hdg/100.0));
    emit setYaw(global_position.hdg / 100.0);
    emit setAltitude(R_altitude);
    emit setVerticleSpeed(vertical_speed);
    emit setMap(global_position.lat / 1e7,global_position.lon / 1e7,global_position.hdg/100.0);
    emit addMessageToLabel(message);
    emit addMessageInfoToLabel(messageInfo);
    message.clear();
    messageInfo.clear();
}
void Show_Values_Class::handleAttitude(const mavlink_message_t& msg) {
    mavlink_attitude_t attitude;
    mavlink_msg_attitude_decode(&msg, &attitude);
    double roll =attitude.roll * 180 / M_PI;
    double pitch=attitude.pitch * 180 / M_PI;
    message.append(QString("ROLL: %1 DEG\n\n").arg(roll));
    message.append(QString("PITCH: %1 DEG\n\n").arg(pitch));
    emit setPitch(pitch);
    emit setRoll(roll);
}
void Show_Values_Class::handlePressure(const mavlink_message_t& msg) {
    mavlink_scaled_pressure_t pressure_data;
    mavlink_msg_scaled_pressure_decode(&msg, &pressure_data);
    double pressure = pressure_data.press_abs; // Basınç verisi (hPa)
    emit setPressure(pressure);
}
void Show_Values_Class::disArm(){
    if (tcpSocket->state() == QTcpSocket::ConnectedState) {
        mavlink_message_t msg;
        mavlink_msg_command_long_pack(MAV_TYPE_GCS, MAV_AUTOPILOT_GENERIC, &msg, 1, 1, MAV_CMD_COMPONENT_ARM_DISARM, 1, 0, 21196, 0, 0, 0, 0, 0);
        sendMavlinkMessage(msg);
    } else {
        emit messageBox_Show("Not Connected", "Please connect to the server first.");
    }
}
void Show_Values_Class::Arm(){
    if (tcpSocket->state() == QTcpSocket::ConnectedState) {
        mavlink_message_t msg;
        mavlink_msg_command_long_pack(MAV_TYPE_GCS, MAV_AUTOPILOT_GENERIC, &msg, 1, 1, MAV_CMD_COMPONENT_ARM_DISARM, 1, 1, 2989, 0, 0, 0, 0, 0);
        sendMavlinkMessage(msg);
    }
}
void Show_Values_Class::Connect_TCP(const QString ip, quint16 port) {
    emit connecting_tcp();
    // Zaten bağlantı varsa önce bağlantıyı keselim.
    if (tcpSocket->state() == QTcpSocket::ConnectedState) {
        tcpSocket->disconnectFromHost();
    }
    // Bağlantıyı başlat
    tcpSocket->connectToHost(ip, port);
}

void Show_Values_Class::DisConnect_TCP(){
    if (tcpSocket->state() == QTcpSocket::ConnectedState) {
        emit updateConnectionStatus(TCPconnected = false);
        tcpSocket->disconnectFromHost();
        emit messageBox_Show("Connection Lost", "TCP Connection Lost.");
    }

}
void Show_Values_Class::change_Mode(int indexofCombobox){
    mavlink_message_t msg;
    mavlink_msg_command_long_pack(MAV_TYPE_GCS, MAV_AUTOPILOT_GENERIC, &msg, 1, 1,
                                  MAV_CMD_DO_SET_MODE, 0, 217,getMode(indexofCombobox), 0, 0, 0, 0, 0);
    sendMavlinkMessage(msg);
}
void Show_Values_Class::Heartbeat(){
    if (startTime == 0) {
        startTime = QDateTime::currentMSecsSinceEpoch(); // İlk HEARTBEAT geldiğinde zamanı al
    }
        uint32_t currentTime = QDateTime::currentMSecsSinceEpoch();
        uint32_t timeInAir = (currentTime - startTime)/1000;

    if (msg.msgid == MAVLINK_MSG_ID_HEARTBEAT) {
        emit updateLabelBackground(true,timeInAir);
    } else {
        emit updateLabelBackground(false,timeInAir);
    }
}
void Show_Values_Class::Go_Coordinate(double lat, double lng) {
    qDebug() << "Latitude:" << lat;
    qDebug() << "Longitude:" << lng;

    // Convert latitude and longitude to MAVLink's expected format
    int32_t lat_mav = static_cast<int32_t>(lat * 1e7);
    int32_t lng_mav = static_cast<int32_t>(lng * 1e7);

    if (tcpSocket->state() == QTcpSocket::ConnectedState) {
        mavlink_message_t waypoint_msg;

        mavlink_msg_mission_item_int_pack(
            MAV_TYPE_GCS, MAV_AUTOPILOT_GENERIC, &waypoint_msg,
            1,  // System ID
            1,  // Component ID
            0,  // Sequence (you may want to adjust this if you're sending multiple waypoints)
            MAV_FRAME_GLOBAL_RELATIVE_ALT,
            MAV_CMD_NAV_WAYPOINT,
            2,  // Current (set to 2 for guided mode)
            1,  // Auto-continue
            0, 0, 0, 0,  // Params 1 to 4 (unused in this example)
            lat_mav,
            lng_mav,
            500,  // Altitude in meters
            MAV_MISSION_TYPE_MISSION
            );

        sendMavlinkMessage(waypoint_msg);
    } else {
        qDebug() << "TCP socket is not connected.";
    }
}


void Show_Values_Class::Remove_Coordinate() {
    if (tcpSocket->state() == QTcpSocket::ConnectedState) {
        mavlink_message_t msg;
        mavlink_msg_command_long_pack(MAV_TYPE_GCS, MAV_AUTOPILOT_GENERIC, &msg, 1, 1,
                                      MAV_CMD_DO_SET_MODE, 0, 217,getMode(11), 0, 0, 0, 0, 0);
        sendMavlinkMessage(msg);
    }
}
// MAVLink mesajını TCP soketi üzerinden gönderme işlevi
void Show_Values_Class::sendMavlinkMessage(const mavlink_message_t& msg) {
    uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
    uint16_t len = mavlink_msg_to_send_buffer(buffer, &msg);
    tcpSocket->write(reinterpret_cast<const char*>(buffer), len);
    tcpSocket->flush();
}

