#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QColor>
#include <QQuickItem>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setCentralWidget(ui->gridWidget);
    hud = new HUD(this);
    ui->hud_Layout->addWidget(hud);
    hud->show();
    show_values_class= new Show_Values_Class(this);
    timer = new QTimer(this);
    ui->quickWidget->setSource(QUrl(QStringLiteral("qrc:/QmlMap.qml")));
    ui->quickWidget->show();
    setupConnections();
    show_values_class->start();
}
MainWindow::~MainWindow() {
    timer->stop();
    delete timer;
    show_values_class->quit();
    show_values_class->wait();
    delete show_values_class;
    delete ui;
}
void MainWindow::addMessageInfoToLabel(QString message){
    ui->plainTextEdit->setPlainText(message);
}
void MainWindow::addMessageToLabel(QString message){
    ui->label_6->setText(message);
}
void  MainWindow::showTCPError(){
    QMessageBox::critical(this, "Not Connected", "Veri okuma hatası!");
}
void MainWindow::on_connectButton_clicked() {

    QString ip = ui->ipLineEdit->text();
    quint16 port = ui->portLineEdit->text().toUShort();
    emit Connect(ip,port);
    timer->start(100);
}
void MainWindow::on_disconnectButton_clicked() {
    onDisconnected();
}
void MainWindow::updateLabelBackground(bool isProgressing,uint32_t time) {
    if (isProgressing) {
        ui->HeartBreak_Label->setStyleSheet("background-color: green;  color:white; border-radius: 7px;");
    } else {
        ui->HeartBreak_Label->setStyleSheet("background-color: red;  color:white; border-radius: 7px;");
    }
    ui->Time_Label->setText(QString::number(time));
}
void MainWindow::on_ArmButton_clicked() {
    emit Arm();
    armed=true;
    updateButtonStyles();
}
void MainWindow::messageBox_Show(QString title,QString message) {
    QMessageBox::warning(this, title, message);
}

void MainWindow::updateConnectionStatus(bool TCPconnected) {
    if (TCPconnected) {        
        ui->statusLabel->setStyleSheet("background-color: green; color:white; border-radius: 15px;");
        ui->connect->setDisabled(true);
        ui->ArmButton->setEnabled(true);
        ui->DisarmButton->setDisabled(false);
        ui->Time_Label->setStyleSheet("color:white; border-radius: 15px;");

    } else {
        ui->label_6->setText("NO CONNECTION");
        ui->plainTextEdit->setPlainText("NO CONNECTION");
        hud->reset();
        updateButtonStyles();
        ui->connect->setDisabled(false);
        ui->statusLabel->setStyleSheet("background-color: red; color:white; border-radius: 15px;");
        ui->HeartBreak_Label->setStyleSheet("background-color: red;  color:white; border-radius: 7px;");
    }
    timer->stop();
    ui->connecting_tcp_label->setVisible(false);
}
void MainWindow::on_DisarmButton_clicked()
{
    qDebug() << "Task 0 çalışıyor, thread ID:" << QThread::currentThread();
    emit DisArm();
    armed=false;
    updateButtonStyles();
}
void MainWindow::updateButtonStyles() {
    if (armed) {
        // Arm modunda: Yeşil arka plan
        ui->ArmButton->setStyleSheet("border-radius: 5px;\n\npadding: 5px;background-color: #2e7d32; color:white; ");
        ui->DisarmButton->setStyleSheet("border-radius: 5px;\n\npadding: 5px;background-color: #e0e0e0;");
        ui->ArmButton->setDisabled(true);
        ui->DisarmButton->setDisabled(false);
    } else {
        // Disarm modunda: Kırmızı arka plan
        ui->ArmButton->setStyleSheet("border-radius: 5px;\n\npadding: 5px;background-color: #e0e0e0;");
        ui->DisarmButton->setStyleSheet("border-radius: 5px;\n\npadding: 5px;background-color: #c62828; color:white;");
        ui->ArmButton->setDisabled(false);
        ui->DisarmButton->setDisabled(true);
    }
}

void MainWindow::on_ChangeModeButton_clicked()
{
    if (combo_Selected_Index < 0) {
        QMessageBox::warning(this, "Warning", "No mode selected.");
        return;
    }
        combo_Selected_Index=ui->ModeListCombobox->currentIndex();
        emit changeMode(combo_Selected_Index);
        ui->ModeListCombobox->setStyleSheet("border-radius: 5px;\nbackground-color: green;\nborder: 2px solid #2c487e;\ncolor: black;\npadding: 5px;\n");
}

void MainWindow::on_ModeListCombobox_currentIndexChanged(int index)
{
        ui->ModeListCombobox->setStyleSheet("background-color: #e0e0e0; color: black; "
                                            "border-radius: 3px; padding: 5px;");

}
void MainWindow::onDisconnected() {
    ui->ArmButton->setEnabled(false);
    ui->DisarmButton->setDisabled(true);
    ui->ChangeModeButton->setEnabled(false);
    ui->label_6->setText("NO CONNECTION");
    ui->plainTextEdit->setPlainText("NO CONNECTION");
    ui->connect->setEnabled(true);
    ui->Time_Label->setStyleSheet("color:red; border-radius: 15px;");
    show_values_class->startTime=0;
    timer->stop();
    emit DisConnect();
}
void MainWindow::connecting_tcp()
{   ui->connecting_tcp_label->setVisible(true);
}
void MainWindow::setupConnections() {
    //timer
    connect(timer, &QTimer::timeout, this, [=]() mutable {
        QString dots = QString(dotCount, '.'); // Noktaların sayısını oluştur
        ui->connecting_tcp_label->setText(text + dots); // Metni güncelle
        dotCount = (dotCount + 1) % 10; // Noktaları 3'e kadar artır, sonra sıfırla
    });
    //Map
    auto obj = ui->quickWidget->rootObject();
    connect(show_values_class, SIGNAL(setMap(QVariant, QVariant,QVariant)), obj, SLOT(addMarker(QVariant, QVariant,QVariant)));
    connect(obj, SIGNAL(rightClickSignal(double, double)), show_values_class, SLOT(Go_Coordinate(double, double)));
    connect(obj, SIGNAL(removerightClickSignal()), show_values_class, SLOT(Remove_Coordinate()));
    // Buton bağlantıları
    connect(ui->connect, &QPushButton::clicked, this, &MainWindow::on_connectButton_clicked);
    connect(ui->disconnect, &QPushButton::clicked, this, &MainWindow::on_disconnectButton_clicked);
    connect(ui->ArmButton, &QPushButton::clicked, this, &MainWindow::on_ArmButton_clicked);

    // Show_Values_Class sinyalleri
    connect(show_values_class, &Show_Values_Class::updateLabelBackground, this, &MainWindow::updateLabelBackground);
    connect(show_values_class, &Show_Values_Class::addMessageInfoToLabel, this, &MainWindow::addMessageInfoToLabel);
    connect(show_values_class, &Show_Values_Class::TCPError, this, &MainWindow::showTCPError);
    connect(show_values_class, &Show_Values_Class::addMessageToLabel, this, &MainWindow::addMessageToLabel);
    connect(show_values_class, &Show_Values_Class::updateConnectionStatus, this, &MainWindow::updateConnectionStatus);
    connect(show_values_class, &Show_Values_Class::messageBox_Show, this, &MainWindow::messageBox_Show);
    connect(show_values_class, &Show_Values_Class::connecting_tcp, this, &MainWindow::connecting_tcp);

    //MainWindow Sinyalleri
    connect(this, &MainWindow::Connect, show_values_class, &Show_Values_Class::Connect_TCP);
    connect(this, &MainWindow::DisConnect, show_values_class, &Show_Values_Class::DisConnect_TCP);
    connect(this, &MainWindow::Arm, show_values_class, &Show_Values_Class::Arm);
    connect(this, &MainWindow::DisArm, show_values_class, &Show_Values_Class::disArm);
    connect(this, &MainWindow::changeMode, show_values_class, &Show_Values_Class::change_Mode);
    //HUD Sinyalleri
    connect(show_values_class, &Show_Values_Class::setAirSpeed, hud, &HUD::setAirSpeed);
    connect(show_values_class, &Show_Values_Class::setPitch, hud, &HUD::setPitch);
    connect(show_values_class, &Show_Values_Class::setRoll, hud, &HUD::setRoll);
    connect(show_values_class, &Show_Values_Class::setYaw, hud, &HUD::setYaw);
    connect(show_values_class, &Show_Values_Class::setAltitude, hud, &HUD::setAltitude);
    connect(show_values_class, &Show_Values_Class::setPressure, hud, &HUD::setPressure);
    connect(show_values_class, &Show_Values_Class::setVerticleSpeed, hud, &HUD::setVerticleSpeed);

}
